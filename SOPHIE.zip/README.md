# Sophie Bot

Imagine this: A pedophile just slipped inside your teen dating server and none of your moderators noticed. They chat it up with some kids and eventually get one into DMs. That kid is now missing or has been assaulted by that pedophile. Now hit the rewind button because now Sophie exists. Sophie will scan the server for known pedophiles as well as attempt to detect potentional pedophilic actvity by looking for keywords. If something is found, it'll alert your moderators to the unusual activity. Your server will be pedophile free and you can rest easy.

#### Our Trello
https://trello.com/b/Z40gGQn9

#### Changelog

##### 1.0.1: Security Update. One security error was fixed in package.json
